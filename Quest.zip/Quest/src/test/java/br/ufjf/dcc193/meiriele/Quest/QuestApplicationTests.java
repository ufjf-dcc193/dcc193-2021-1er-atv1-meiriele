package br.ufjf.dcc193.meiriele.Quest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuestApplicationTests {

	@Test
	void contextLoads() {
	}

}
